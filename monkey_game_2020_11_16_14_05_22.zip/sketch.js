
var monkey , monkey_running
var spawnBanana,banana ,bananaImage, spawnobstacle, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var survivalTime=0;
function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(600,200);
  monkey=createSprite(80,315,20,20);
  monkey.addAnimation("moving",monkey_running);
  monkey.scale=0.1;
  
  ground=createSprite(400,350,900,10);
  ground.velocityX=-4;
  ground.x=ground.width/2;
  console.log(ground.x);

  
}


function draw() {
drawSprites();
  if (keyDown("space")&&monkey.y>=100){
    monkey.velocityY=-3;
  }
    if (ground.x<0){
    ground.x=ground.width/2;
  spawnBanana;
  spawnObstacle;
}
function banana(){
  if (frameCount%60===0){
    banana=createSprite(600,20,50,50);
    banana.addImage("banana",bananaImage);
    banana.velocityX=-5;
    banana.y=Math.round(random(10,60));
    banana.scale=0.8;
  }
}
  function spawnObstacle
if (frameCount% 60=== 0){
    obstacles=createSprite(600,180,40,20);
   obstacle.addImage("obstacles",obstacleImage);
   obstacle.velocityX=-5;
   obstacle.y=Math.round(random(10,60));
   obstacle.scale=0.8;
}